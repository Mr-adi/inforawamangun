<?php

/**
 * Include Vafpress Framework
 */
require_once 'bootstrap.php';

/**
 * Include Custom Data Sources
 */
require_once 'data_sources.php';
/*
 * EOF
 */