<?php

/**
 * Fired during plugin activation
 *
 * @link       http://themeforest.net/user/PixFlow/portfolio
 * @since      1.0.0
 *
 * @package    PX_Metabox
 * @subpackage PX_Metabox/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    PX_Metabox
 * @subpackage PX_Metabox/includes
 * @author     Pixflow <pxflow@gmail.com>
 */
class PX_Metabox_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
