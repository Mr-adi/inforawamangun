<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://themeforest.net/user/PixFlow/portfolio
 * @since      1.0.0
 *
 * @package    PX_Metabox
 * @subpackage PX_Metabox/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    PX_Metabox
 * @subpackage PX_Metabox/includes
 * @author     Pixflow <pxflow@gmail.com>
 */
class PX_Metabox_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
